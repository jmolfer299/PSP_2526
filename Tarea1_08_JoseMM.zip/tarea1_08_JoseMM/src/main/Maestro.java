package main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

import java.util.List;

/**
 * @author josem
 */
public class Maestro { 
	public static void main(String[] args) {
		try {
			//Pruebo cambiar las variables por si se introducen letras
			int gotas = Integer.parseInt(args[0]); 
			int cantidadProcesos = Integer.parseInt(args[1]);

			//Si cumple las condiciones empieza el programa
			if ((args.length == 2) && (gotas >= 0) && (cantidadProcesos >= 0)
					&& (gotas > cantidadProcesos)) { 

				//Suma definida, lista de procesos para cada uno de los esclavos
				double suma = 0;
				List<Process> procesos = new ArrayList<>();
				int gotasPorEsclavo = gotas/cantidadProcesos;

				//Vamos generando esclavos mandado los valores por el process builder
				for(int i = 0; i<cantidadProcesos; i++) {
					ProcessBuilder pb = new ProcessBuilder("java", "-cp", "bin", "main.Esclavo",String.valueOf(gotas), String.valueOf(gotasPorEsclavo));
					pb.redirectErrorStream(true);
					Process proceso = pb.start();		
					procesos.add(proceso);
				}

 
				//Vamos viendo los procesos y las respuestas
				for (int i = 0; i < procesos.size(); i++) {
					Process proceso = procesos.get(i);

					BufferedReader esclavoSalida = new BufferedReader(
							new InputStreamReader(proceso.getInputStream())
							);

					double respuesta = Double.parseDouble(esclavoSalida.readLine());
					suma += respuesta;
					esclavoSalida.close();
					proceso.waitFor();
				}
				System.out.println("Los procesos esclavo aproximan pi a: "+suma);

			} else {
				System.out.println("Se deben introducir DOS argumentos, deben de ser mayores que cero y el primero"
						+ " debe ser mayor que el segundo");
			}

		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
