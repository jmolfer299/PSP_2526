package main;

public class Esclavo {
	public static void main(String[] args) {
		

		//Recibimos los valores, llamamos al método MonteCarlo y devolvemos la respuesta
		int gotas = Integer.parseInt(args[0]);
		int gotasPrueba = Integer.parseInt(args[1]);
		
		double respuesta = MonteCarlo.sequentialMonteCarlo(gotas, gotasPrueba);

        System.out.print(respuesta);
	}
} 

