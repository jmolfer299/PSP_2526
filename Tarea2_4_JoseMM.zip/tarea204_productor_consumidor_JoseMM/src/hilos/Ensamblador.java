package hilos;

import java.util.concurrent.ThreadLocalRandom;

import main.FabricaCentral;

/**
 * Ensamblador que coge piezas de la cola general
 */

public class Ensamblador implements Runnable{

	String nombre;
	int piezasProcesadas = 0;

	public Ensamblador(String nombre) {
		super();
		this.nombre = nombre;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	@Override
	public void run() {
		while(piezasProcesadas < 30) {
			System.out.println("CONSUME: "+nombre+" esperando pieza...\n");
			try {
				FabricaCentral.piezas.take();
				Thread.sleep(ThreadLocalRandom.current().nextInt(8000, 15001));
				piezasProcesadas++;
				System.out.println("CONSUME: "+nombre +" he cogido una pieza. Ahora\r\n"
						+ "llevo "+piezasProcesadas +" piezas consumidas quedan "+(FabricaCentral.piezas.size() - 1)+" en la cola\r\n"
						+ "compartida\n");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
