package hilos;

import java.util.concurrent.ThreadLocalRandom;
import models.ContadorPiezas;

/**
 * Generador que añade piezas a la cola
 */
public class GeneradorPiezas implements Runnable {
	
	static int contador = 0;
	int id;
	ContadorPiezas contadorPiezas;
	int contadorGeneradas = 0;

	public GeneradorPiezas(ContadorPiezas contadorPiezas) {
	    this.id = ++contador;  
	    this.contadorPiezas = contadorPiezas;
	}
	
	

	@Override
	public void run() {
		while(contadorGeneradas < 10) {	
			try {
				System.out.println("El generador con id: "+id+" está esperando para generar pieza\n");
				Thread.sleep(ThreadLocalRandom.current().nextInt(5000, 10001));
				contadorGeneradas++;
				contadorPiezas.incrementar(id);
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		}
	}

}