package main;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import hilos.Ensamblador;
import hilos.GeneradorPiezas;
import models.ContadorPiezas;

/**
 * Código principal de la app
 */
public class FabricaCentral {
	
	public static BlockingQueue<Integer> piezas = new ArrayBlockingQueue<>(10);
	
	public static void main(String[] args) throws InterruptedException {
		
		int numGen = 3;
		ContadorPiezas cuentaMaster = new ContadorPiezas();
		List<Thread> fabrica = new ArrayList<>();
		Ensamblador ensamblador = new Ensamblador("Paco el ensamblador");
		
		for(int i = 0; i<numGen; i++) {
			GeneradorPiezas generador = new GeneradorPiezas(cuentaMaster);
			Thread hilo = new Thread(generador);
			fabrica.add(hilo);
			
		}
		Thread hilo2 = new Thread(ensamblador);
		fabrica.add(hilo2);
		
		for (Thread thread : fabrica) {
			thread.start();
		}
		for (Thread thread : fabrica) {
			thread.join();
		}
		
		System.out.println("\nJornada finalizada piezas desaprovechadas: "+ piezas.size());
	}
}
