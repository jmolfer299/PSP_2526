package models;

import main.FabricaCentral;

/**
 * Clase que añade piezas a la cola
 */
public class ContadorPiezas {
	
	public synchronized void incrementar(int id) throws InterruptedException {
	    FabricaCentral.piezas.put(1);
	    System.out.println("El generador con id: "+id+" ha generado una pieza \n"
	            +"Piezas totales: "+FabricaCentral.piezas.size()+"\n");
	}

}
