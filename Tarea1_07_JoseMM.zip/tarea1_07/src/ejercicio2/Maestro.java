package ejercicio2;

import java.io.*;
import java.util.Random;

/**
 * Clase maestro ejercicio2
 * @author josem
 */
public class Maestro {
    public static void main(String[] args) throws IOException, InterruptedException {

        // Validar argumentos
        if (args.length != 2) {
            System.err.println("Debe haber 2 parametros");
           
        }else {
        	double min, max;
        	try {
        		min = Double.parseDouble(args[0]);
        		max = Double.parseDouble(args[1]);
        	} catch (NumberFormatException e) {
        		System.err.println("Los argumentos deben ser números reales.");
        		return;
        	}
        	
        	if (min > max) {
        		System.err.println("El primer argumento debe ser menor o igual al segundo.");
        		return;
        	}
        	
        	// Crear proceso esclavo
        	ProcessBuilder pb = new ProcessBuilder("java", "-cp", "bin", "ejercicio2.Esclavo");
        	pb.redirectErrorStream(true);
        	Process proceso = pb.start();
        	
        	BufferedWriter esclavoEntrada = new BufferedWriter(new OutputStreamWriter(proceso.getOutputStream()));
        	BufferedReader esclavoSalida = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
        	
        	// Generar y enviar 1000 números aleatorios
        	Random rnd = new Random();
        	for (int i = 0; i < 1000; i++) {
        		double numero = min + rnd.nextDouble() * (max - min);
        		esclavoEntrada.write(String.valueOf(numero));
        		esclavoEntrada.newLine();
        	}
        	
        	// Línea vacía para indicar el fin de la lista
        	esclavoEntrada.newLine();
        	esclavoEntrada.flush();
        	
        	// Esperar respuesta del esclavo
        	String respuesta = esclavoSalida.readLine();
        	System.out.println("La suma total recibida del esclavo es: " + respuesta);
        	
        	//Cerrar flujos
        	esclavoEntrada.close();
        	esclavoSalida.close();
        	proceso.waitFor();
        	
        	System.out.println("Proceso maestro finalizado correctamente.");
        }
    }
}
