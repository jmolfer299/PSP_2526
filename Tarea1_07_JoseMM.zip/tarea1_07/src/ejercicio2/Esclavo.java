package ejercicio2;

import java.io.*;
/**
 * Clase esclavo ejercicio 2
 * @author josem
 */
public class Esclavo {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        double suma = 0.0;
        String linea;

        // Leer números hasta encontrar una línea vacía o EOF
        while ((linea = br.readLine()) != null && !linea.trim().isEmpty()) {
            try {
                suma += Double.parseDouble(linea.trim());
            } catch (NumberFormatException e) {
                // Ignora líneas no numéricas
            }
        }

        // Enviar resultado al maestro
        System.out.println(suma);
    }
}
