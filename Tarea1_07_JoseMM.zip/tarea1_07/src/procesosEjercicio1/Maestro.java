package procesosEjercicio1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

/**
 * Clase Maestro del ejercicio1
 * @author josem 
 */
public class Maestro {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String texto = null;

		//define el proceso
		ProcessBuilder esclavo = new ProcessBuilder("java", "-cp", "bin", "procesosEjercicio1.Esclavo");
		Process proceso = esclavo.start(); 
		
		//inicializa el lector y el escritor de la clase esclavo
		BufferedWriter esclavoEntrada = new BufferedWriter(new OutputStreamWriter(proceso.getOutputStream()));
		BufferedReader esclavoSalida = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
		
		//recoge y manda texto hasta que se mande un texto vacio
		do {
			System.out.println("Ingrese un texto: ");
			texto = sc.nextLine();
			
			if(!texto.isEmpty()) {
				esclavoEntrada.write(texto);
				esclavoEntrada.newLine();
				esclavoEntrada.flush();
				
				String respuesta = esclavoSalida.readLine();
				System.out.println("Respuesta del esclavo: "+ respuesta);
			}
		} while (!texto.isEmpty());
		esclavoEntrada.newLine();
		esclavoEntrada.flush();
		sc.close();
		proceso.destroy();
		
		System.out.println("Maestro finalizado");
	}

}
