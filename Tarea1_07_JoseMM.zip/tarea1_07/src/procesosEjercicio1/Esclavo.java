package procesosEjercicio1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Clase esclavo ejercicio1
 * @author josem
 */
public class Esclavo {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String linea;

		// Leer mientras haya texto
		while ((linea = br.readLine()) != null && !linea.isEmpty()) {
			int op = (int) (Math.random() * 3);
			String resultado;

			// Seleccionar resultado de forma aleatoria
			switch (op) {
			case 0 -> resultado = linea.toUpperCase(); 
			case 1 -> resultado = linea.toLowerCase();
			default -> resultado = capitalizar(linea); 
			}

			// Enviar resultado al maestro
			System.out.println(resultado);
		}
	}

	private static String capitalizar(String linea) {
		char[] lineaArray = linea.toCharArray();
		String cambio = String.valueOf(lineaArray[0]);
		lineaArray[0] = cambio.toUpperCase().toCharArray()[0]; 
		
		for (int i = 0; i<lineaArray.length; i++) {
			if(lineaArray[i] == ' ') {
				cambio = String.valueOf(lineaArray[i+1]);
				lineaArray[i+1] = cambio.toUpperCase().toCharArray()[0]; 
			}
		}

		return new String(lineaArray).trim();
	}


}

