package ejercicio2;

/**
 * Proceso esclavo que realiza la suma acumulativa de los números introducidas
 */
public class Esclavo {
    public static void main(String[] args) {
        try {
            int inicio = Integer.parseInt(args[0]);
            int fin = Integer.parseInt(args[1]);
            long suma = 0;
            
            for(int i = inicio; i <= fin; i++) {
                suma += i;
            }
            
            System.out.println(suma);
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}