package ejercicio2;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
/**
 * Maestro que habiendole dado dos números depende de los parámetro que recibe realiza distintos procesos
 */
public class Maestro {
    public static void main(String[] args) {
        if(args.length != 2) {
            System.err.println("Se deben introducir exactamente 2 parámetros");
            return;
        }
        
        try {
            int num1 = Integer.parseInt(args[0]);
            int num2 = Integer.parseInt(args[1]);
            int mayor = Math.max(num1, num2);
            int menor = Math.min(num1, num2);
            int resta = mayor - menor;
            
            List<Process> procesos = new ArrayList<>();
            int numProcesos;
            
            if(resta < 25) {
                numProcesos = 1;
            } else if(resta >= 25 && resta < 100) {
                numProcesos = 2;
            } else {
                numProcesos = Runtime.getRuntime().availableProcessors();//Devuelve el número de núcleos 
            }
            
            int rangoTotal = mayor - menor + 1;
            int rangoProProceso = rangoTotal / numProcesos;
            
            for(int i = 0; i < numProcesos; i++) {
                int inicio = menor + (i * rangoProProceso);
                	int fin;
                	if (i == numProcesos - 1) {
                	    fin = mayor; 
                	} else {
                	    fin = inicio + rangoProProceso - 1;
                	}
                
                ProcessBuilder pb = new ProcessBuilder("java", "-cp", "bin", 
                                                      "ejercicio2.Esclavo",
                                                      String.valueOf(inicio),
                                                      String.valueOf(fin));
                pb.redirectErrorStream(true);
                Process proceso = pb.start();
                procesos.add(proceso);
            }
            

            long sumaTotal = 0;
            for(Process p : procesos) {
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(p.getInputStream())
                );
                String linea;
                while((linea = reader.readLine()) != null) {
                    try {
                        sumaTotal += Long.parseLong(linea.trim());
                    } catch(NumberFormatException e) {
                        System.err.println("Error parseando: " + linea);
                    }
                }
                reader.close();
                p.waitFor();
            }
            
            System.out.println("Suma total: " + sumaTotal);
            System.out.println("Procesos utilizados: " + numProcesos);
            
        } catch(Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}