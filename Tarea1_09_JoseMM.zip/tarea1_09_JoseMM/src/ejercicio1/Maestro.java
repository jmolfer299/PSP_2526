package ejercicio1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Proceso que lanza varios esclavos con las distintas vocales, coge valores del fichero y suma los totales
 */
public class Maestro {

	public static void main(String[] args) {

		try {			
			if(args.length == 1) {
				long tiempoInicio = System.nanoTime();//Temporizador de proceso
				int[] cuentas = new int[5];
				String[] vocales = {"A","E","I","O","U"};

				List<Process> procesos = new ArrayList<>();

				File archivo = new File("respuestas.txt");
				if(archivo.exists()) {
					archivo.delete();
				}
				archivo.createNewFile();

				for(int i = 0; i<cuentas.length; i++) {
					ProcessBuilder pb = new ProcessBuilder("java", "-cp", "bin", "ejercicio1.Esclavo", args[0] ,vocales[i]);
					pb.redirectErrorStream(true);
					Process proceso = pb.start();		
					procesos.add(proceso);
				}

				try(BufferedWriter escritorRespuestas = new BufferedWriter(new FileWriter(archivo, true))) {
					for (int i = 0; i < procesos.size(); i++) {
						Process proceso = procesos.get(i);

						BufferedReader esclavoSalida = new BufferedReader(
								new InputStreamReader(proceso.getInputStream())
								);

						String lineaEsclavo;
						while ((lineaEsclavo = esclavoSalida.readLine()) != null) {
							escritorRespuestas.write(lineaEsclavo);
							escritorRespuestas.newLine();
						}

						esclavoSalida.close();
						proceso.waitFor();
						escritorRespuestas.flush(); 
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
				
				String linea = null;
				int sumaVocales = 0;
				try(BufferedReader lector = new BufferedReader(new FileReader("respuestas.txt"))) {
					while ((linea = lector.readLine()) != null) {
						String[] split = linea.split(" ");
						for(int i = 0; i < split.length ;i++) {
							try {
								int numero = Integer.parseInt(split[i].trim());
								sumaVocales += numero;

							} catch (NumberFormatException e) {
							}
						}
					}

				}catch(Exception e) {
					e.printStackTrace();
				}

				long tiempoFin = System.nanoTime();
				long duracionNanos = tiempoFin - tiempoInicio;
				double duracionMilis = duracionNanos / 1_000_000.0;

				try(BufferedWriter escritor = new BufferedWriter(new FileWriter("respuestas.txt",true))){
					escritor.write("Total de vocales contadas: "+sumaVocales);
		            escritor.newLine();
		            escritor.write("Tiempo total: "+duracionMilis+" ms");
		            System.out.println("El programa ha escrito correctamente");
				}catch(Exception e) {
					e.printStackTrace();
				}
			}else{
				System.err.println("El programa debe recibir solo un parámetro, la ruta completa del archivo");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
