package ejercicio1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class CuentaLetras {
	/**
	 * Método que recibe una letra vocal y las cuenta en el archivo
	 * @param letra
	 * @param nombreFichero
	 * @return
	 */

	public static int cuentaLetras(String letra, String nombreFichero) {			
		int contador = 0;
		char letraMinuscula =letra.toLowerCase().toCharArray()[0];
		char letraMayuscula =letra.toUpperCase().toCharArray()[0];
		String linea = null;
		String ruta = new File(nombreFichero).getAbsolutePath();
		try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
			while ((linea = lector.readLine()) != null) {

				for (int x = 0; x < linea.length(); x++) {
					char caracterActual = linea.charAt(x);
					if ((caracterActual == letraMayuscula) || (caracterActual == letraMinuscula)) {
						contador++;
					}
				}
			}

		}catch(Exception e) {
			System.err.println("Error insesperado!!");
			e.printStackTrace();
		}


		return contador;
	}

}
