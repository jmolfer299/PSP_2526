package ejercicio1;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 * Esclavo que cuenta cuanto tarda, el número de veces que aparece la vocal y escribe en el archivo
 */
public class Esclavo {
	public static void main(String[] args) {
		long tiempoInicio = System.nanoTime();
		
		String nombreArchivo = args[0];
		String letra = args[1];

		int respuesta = CuentaLetras.cuentaLetras(letra, nombreArchivo);

		long tiempoFin = System.nanoTime();

		long duracionNanos = tiempoFin - tiempoInicio;
		double duracionMilis = duracionNanos / 1_000_000.0;

		try (BufferedWriter escritor = new BufferedWriter(new FileWriter("respuestas.txt", true))) {
			escritor.write("Se ha encontrado la letra "+ letra +
					" un total de "+ respuesta+ " veces en el archivo "+nombreArchivo +
					" El tiempo total del programa fue: " + duracionMilis + " ms");
			escritor.newLine();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
