package workers;

import java.util.Random;

import main.Main;
import utils.UtilsEspera;

/**
 * Clase runnable de los clientes: comen pizzas de forma aleatoria cumpliendo una serie de condiciones
 * 
 */
public class Clientes implements Runnable {

	public int contador = 0;
	public int id;
	static Random rnd = new Random();


	public Clientes(int id) {
		this.contador = 0;
		this.id = id;
	}


	public int getContador() {
		return contador;
	}

	public void comer() {
		this.contador ++;
	}



	@Override
	public void run() {
		int tiempoEspera = 0;
		while(true) {
			if(contador < 5) {		
				tiempoEspera = UtilsEspera.tiempoEsperaCliente(contador);
	            synchronized(Main.class) {
	                while(Main.bandeja == 0) {
	                    try {
	                        Thread.sleep(tiempoEspera * 1000);
	                    } catch (InterruptedException e) {
	                        e.printStackTrace();
	                    }
	                }
	                Main.bandeja--;
	                comer();
	            }
	            System.out.println("Un cliente con id: "+id+" ha comido despues de esperar "+tiempoEspera +" seg su pizza numero "+contador);
			}else {
				System.out.println("El cliente con id: "+id+" esta satisfecho");
				Main.activos --;
				return;
			}

		}

	}
}