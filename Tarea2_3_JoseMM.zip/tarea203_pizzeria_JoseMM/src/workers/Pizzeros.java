package workers;

import java.util.Random;

import main.Main;
import utils.UtilsEspera;

/**
 * Clase runnable de los pizzeros: genera pizzas de forma aleatoria
 * 
 */
public class Pizzeros implements Runnable {

	public int id;
	public Pizzeros(int id) {
		this.id = id;
	}

	static Random rnd = new Random();
	@Override
	public void run() {
		int tiempoEspera = 0;
		while(true) {			
			if(Main.activos == 0) {
				return;
			}
			try {
				tiempoEspera = UtilsEspera.tiempoPizzero();
				Thread.sleep(tiempoEspera * 1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Main.bandeja ++;
			System.out.println("Un cocinero con id: "+id+" ha cocinado despues de esperar "+tiempoEspera +" seg ");

		}


	}

}
