package main;

import java.util.ArrayList;

import java.util.List;

import workers.*;

/**
 * Clase Main: principal del proyecto, contiene pruebas de entrada de parámetros y el programa en si
 * @author josem
 */
public class Main {

	public static int activos = 0;
	public static int bandeja = 0;
	
	public static void main(String[] args) throws InterruptedException {

		int numC;
		int numP;

		if(args.length != 2) {
			System.err.println("Se deben introducir 2 parámetros numéricos: \n 1- Número de clientes \n 2- Número de Pizzeros");
			return;
		}

		try {
			numC = Integer.parseInt(args[0]);
			numP = Integer.parseInt(args[1]);
			activos = numC;

		}catch(Exception e){
			System.err.println("Se deben introducir 2 parámetros numéricos: \n 1- Número de clientes \\n 2- Número de Pizzeros");
			return;
		}

		/**
		 * Listas para hilos y ver la cantidad comida por cada cliente
		 */
		List<Thread> clientela = new ArrayList<>();
		List<Thread> cocineros = new ArrayList<>();
		List<Clientes> clientegordos = new ArrayList<>();
		
		for(int i = 0; i<numC; i++) {
			Clientes cliente = new Clientes(i+1);
		    Thread hilo = new Thread(cliente);
			clientela.add(hilo);
			clientegordos.add(cliente);
		}
		
		for(int i = 0; i<numP; i++) {
			Pizzeros pizzero = new Pizzeros(i+1);
		    Thread hilo = new Thread(pizzero);
			cocineros.add(hilo);
		}
		
		for (Thread cliente : clientela) {
			cliente.start();
		}
		for (Thread cocinero : cocineros) {
			cocinero.start();
		}
		
		
		for (Thread cliente : clientela) {
			cliente.join();
		}
		for (Thread cocinero : cocineros) {
			cocinero.join();
		}
		
		
		int pizzaComida = 0;
		for (Clientes clientes : clientegordos) {
			pizzaComida += clientes.getContador(); 
		}
		System.out.println("Dia finalizado total de pizza consumida: "+pizzaComida);
		System.out.println("Se han desperdiciado "+bandeja+" pizzas");
		

	}

}
