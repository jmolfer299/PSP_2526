package utils;

import java.util.Random;

public class UtilsEspera {
	
	static Random rnd = new Random();
	
	/**
	 * Tiempo de espera de cada cliente
	 * @param contador
	 * @return
	 */
	public static int tiempoEsperaCliente(int contador) {
		
		int tiempo = 0;

		if(contador == 0) {
			tiempo = (rnd.nextInt(6) + 10);
		}else {
			tiempo = (rnd.nextInt(11) + 20);
		}

		return tiempo;
	}
	
	/**
	 * Tiempo de espera de cada pizzero
	 * @return
	 */
	public static int tiempoPizzero() {
		return (rnd.nextInt(6) + 5);
	}

}
