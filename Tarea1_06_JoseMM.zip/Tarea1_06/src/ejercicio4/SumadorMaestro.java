package ejercicio4;

import java.io.File;
import java.io.IOException;

public class SumadorMaestro {
    public static void main(String[] args) {

    	File inputFile = new File("C:\\Users\\josem\\PSP\\Tarea1_06\\numeros.txt");
    	File outputFile = new File("C:\\Users\\josem\\PSP\\Tarea1_06\\resultado.txt");
    	File jarFile = new File("C:\\Users\\josem\\PSP\\Tarea1_06\\jar\\sumador.jar");
    	
        ProcessBuilder pb = new ProcessBuilder("java", "-jar", jarFile.getAbsolutePath());

        pb.redirectInput(inputFile);  
        pb.redirectOutput(outputFile); 

        try {
            Process process = pb.start();

            int exitCode = process.waitFor();
            System.out.println("Proceso terminado con código: " + exitCode);
            System.out.println("Revisa el archivo 'resultado.txt' para ver la suma.");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}