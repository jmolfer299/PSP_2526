package ejercicio2;

public class LlamaGenerador {
    public static void main(String[] args) {
        try {
  
            String nombreArchivo = "mi_archivo_personalizado.txt";

            ProcessBuilder pb = new ProcessBuilder("java","-cp","bin", "ejercicio2.GeneraArchivo", nombreArchivo);

            pb.inheritIO();

            Process proceso = pb.start();

            int exitCode = proceso.waitFor();
            System.out.println("Generador terminó con código: " + exitCode);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
