package ejercicio2;

import java.io.FileWriter;
import java.io.IOException;

public class GeneraArchivo {
    public static void main(String[] args) {
        String nombreArchivo = "salida.txt";
        if (args.length > 0) {
            nombreArchivo = args[0];
        }

        try (FileWriter writer = new FileWriter(nombreArchivo)) {
            writer.write("Archivo generado correctamente: " + nombreArchivo);
            System.out.println("Archivo creado: " + nombreArchivo);
        } catch (IOException e) {
            System.err.println("Error al crear el archivo: " + e.getMessage());
        }
    }
}
