package ejercicio3;

import java.io.IOException;

public class LlamaGeneradorModificado {
    public static void main(String[] args) {
        try {
        	
            ProcessBuilder pb = new ProcessBuilder();

            pb.inheritIO();
            
            pb.command("java","-cp","bin", "ejercicio3.GeneradorModificado", "archivo1.txt");
            Process p1 = pb.start();
            p1.waitFor();

            pb.command("java","-cp","bin", "ejercicio3.GeneradorModificado", "ejercicio3.txt");
            Process p2 = pb.start();
            p2.waitFor();

            pb.command("java","-cp","bin",  "ejercicio3.GeneradorModificado");
            Process p3 = pb.start();
            p3.waitFor();

            System.out.println("Todos los procesos han terminado correctamente.");

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
