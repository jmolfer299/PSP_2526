package ejercicio5;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class AmpliacionNota {

    public static void main(String[] args) {
    	
        if (args.length != 1) {
            System.out.println("Debes proporcionar un directorio como parámetro.");
            System.exit(1);
        }

        File dir = new File(args[0]);

        if (!dir.exists() || !dir.isDirectory()) {
            System.out.println("El parámetro proporcionado no es un directorio válido.");
            System.exit(1);
        }

        File salida = new File("salida.txt");

        try (FileWriter writer = new FileWriter(salida)) {
        	
            File[] archivos = dir.listFiles();
            if (archivos != null) {
                for (File f : archivos) {
                	
                    writer.write(f.getName() + ": " + f.length() + " bytes\n");
                }
            }
            System.out.println("Se ha generado 'salida.txt'"+ " Ruta: "+salida.getAbsolutePath()+" con los tamaños de los archivos.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
