package ejercicio1;

import java.nio.file.Paths;

public class Ejercicio1 {
	public static void main(String[] args) {
        try {
        	String origen = "C:\\Windows\\explorer.exe";
        	String destino = Paths.get("").toAbsolutePath().toString() + "\\"+ "explorer.exe";
        	
        	ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "copy", origen, destino);
            Process proceso = pb.start();
            int exitCode = proceso.waitFor();
            System.out.println("Proceso finalizado con código: " + exitCode);
            
            if (exitCode == 0) {
                System.out.println("Archivo copiado con éxito a: " + destino);
            } else {
                System.out.println("Error al copiar el archivo.");
            }
        }catch(Exception e) {
        	e.printStackTrace();
        }
	}
}
