/**
 * 
 */
package psp.unidad01.relacion05c;

/**
 * Este es el tercer apartado lo deben hacer los alumnos/as
 * @author Pedro Vargas
 */
public class Ejercicio03 {

	/**
	 * Escribe por pantalla los parámetrso en mayúsculas.
	 * @param args se admite uno o más parámetros en otro caso error
	 */
	public static void main(String[] args) {
		if (args.length < 1) {
			System.err.println("ERROR. Debes proporcionar como mínimo un parámetro.");
		} else {
			for (String cadena : args) {
				System.out.println(cadena.toUpperCase());
			}
		}
	}

}
