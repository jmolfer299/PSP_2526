package psp.unidad01.relacion05;
/**
 * Código para la tarea 1.05b
 * Al alumno se le entrega el .class
 * @author Pedro Vargas
 */
public class Ejercicio05b {


		/**
		 * @param args Se espera un argumento si no error
		 */
		public static void main(String[] args) {
			
			if (args.length != 1) {
				System.err.println("ERROR. Debes proporcionar un parámetro con tu nombre y apellidos");
			}
			else {
				System.out.println("No me creo que te llames " + args[0] + ". Really");
			}
		}
	
}
