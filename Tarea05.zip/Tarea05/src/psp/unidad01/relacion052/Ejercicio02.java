package psp.unidad01.relacion052;
/**
 * Código para la tarea 1.05b
 * Al alumno se le entrega el .class
 * @author Pedro Vargas
 */
public class Ejercicio02 {

	/**
	 * @param args Se espera un argumento si no error
	 */
	public static void main(String[] args) {
		
		if (args.length != 1) {
			System.err.println("ERROR. Debes proporcionar un parámetro con tu nombre y apellidos");
		}
		else {
			System.out.println("Sabes ejecutar un .JAR desde la línea de comandos " + args[0] + ". Enhorabuena");
		}
	}


}
