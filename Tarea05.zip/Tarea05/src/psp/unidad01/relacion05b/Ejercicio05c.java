
package psp.unidad01.relacion05b;

/**
 * Código para la tarea 1.05c
 * Al alumno se le entrega el .class
 * @author Pedro Vargas
 */
public class Ejercicio05c {

	/**
	 * @param args Se espera un argumento si no error
	 */
	public static void main(String[] args) {
		
		if (args.length != 1) {
			System.err.println("ERROR. Debes proporcionar un parámetro con tu nombre y apellidos");
		}
		else {
			System.out.println("Un tío de mi primo también se llamaba " + args[0]);
		}
		


	}

}
